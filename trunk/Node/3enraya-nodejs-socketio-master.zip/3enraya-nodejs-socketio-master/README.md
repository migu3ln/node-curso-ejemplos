Juego 3 en raya más chat
========================

Aplicación NodeJS para jugar al 3 en raya con otros jugadores usando websockets gracias a la libreria Socket.io.

Sobre mí: [Nazarí González](http://www.nazariglez.com)
